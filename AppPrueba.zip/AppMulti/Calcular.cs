﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AppMulti
{
    public class Calcular
    {
        public int multiplicar(int a, int b)
        {
            return a * b;
        }
    }
}
