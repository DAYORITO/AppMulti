namespace PruebasMulti
{
    public class CalcularTest
    {
        [Fact]
        public void TestMulti()
        {
            // Arrange
            var calc = new AppMulti.Calcular();
            int a = 3;
            int b = 5;
            int expected = 15;
            // Act
            int result = calc.multiplicar(a, b);
            // Assert
            Assert.Equal(expected, result);

        }
    }
}